import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as plt

df=pd.read_excel("BASE01.CREDITO.xlsx")

dfMediaSexo=df[["sexo","valorcredito"]]\
.groupby(by=["sexo"]).sum().reset_index()

st.title("Layout: Sidebar, Colunas e Abas")


# ABAS
aba1, aba2,aba3,aba4 = st.tabs(\
    ["Tabela", "Estatísticas","Gráfico","Pizza"])
with aba1:
    st.dataframe(df)
with aba2:
    st.write(df.describe())
with aba3:
    st.bar_chart\
    (data=dfMediaSexo, x="sexo",y="valorcredito")
with aba4:
    fig=plt.pie(\
    dfMediaSexo, names="sexo",values="valorcredito",color=['red','blue'])
    st.plotly_chart(fig)
    